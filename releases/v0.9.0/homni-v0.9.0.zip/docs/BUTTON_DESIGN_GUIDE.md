# Homni UI Design Guide

This document defines the styling conventions used in the Homni dashboard for consistent user interface elements.

## Button Types

### Primary Button
Primary buttons are used for the main actions on a page or in a component.

- **Background (Static)**: `var(--primary-button)`
- **Background (Hover)**: `var(--primary-button)` + 10% white highlight
- **Text (Static)**: `var(--primary-button-text)`
- **Text (Hover)**: `var(--primary-button-text)`
- **Shadow**: None
- **Usage**: Main actions, such as "Add Server"
- **CSS Classes**: `.add-button`, `.btn-primary`

### Secondary Button
Secondary buttons are used for supporting actions on a page or in a component.

- **Background (Static)**: `var(--secondary-button)`
- **Background (Hover)**: `var(--secondary-button)` + 10% white highlight 
- **Text (Static)**: `var(--secondary-button-text)`
- **Text (Hover)**: `var(--secondary-button-text)`
- **Shadow**: None
- **Usage**: Supporting actions, such as "Import", "Export", "Sort" 
- **CSS Classes**: `.header-button`, `.import-button`, `.export-button`, `.sort-button`, `.btn-secondary`, `.btn-cancel`

### Tertiary Button
Tertiary buttons are used for actions within cards or as less prominent options.

- **Background (Static)**: `var(--server-background)` (transparent)
- **Outline (Static)**: `var(--accent-text)`
- **Text (Static)**: `var(--accent-text)`
- **Background (Hover)**: `var(--accent-text)`
- **Outline (Hover)**: None
- **Text (Hover)**: `var(--primary-button-text)` (typically white)
- **Usage**: In-card actions, such as "Add Service"
- **CSS Classes**: `.small-button`, `.server-actions .small-button`

### Delete/Danger Button
Delete buttons are a special type of button used for destructive actions.

- **Background (Static)**: Transparent
- **Outline (Static)**: `var(--status-red)`
- **Text (Static)**: `var(--status-red)`
- **Background (Hover)**: `var(--status-red)`
- **Outline (Hover)**: `var(--status-red)`
- **Text (Hover)**: `var(--primary-button-text)` (typically white)
- **Usage**: Destructive actions, such as "Delete Server", "Delete Service"
- **CSS Classes**: `.small-button.delete`, `.btn-delete`

## Button Sizing and Layout

All buttons maintain a consistent height of 38px and use the following common properties:

- **Height**: 38px
- **Padding**: 0.5rem 1rem
- **Border Radius**: 4px
- **Font Size**: 0.9rem
- **Min Width**: 90px (ensures consistent button sizing)
- **Display**: inline-flex
- **Alignment**: center (both horizontal and vertical)

## Card Components

### Server Card
Server cards are container components that display server information and host service items.

- **Background**: `var(--server-background)`
- **Text Color**: `var(--service-text)` for titles, `var(--secondary-text)` for metadata
- **Border Radius**: 8px
- **Padding**: 1.25rem
- **Border**: None
- **Shadow**: None
- **Layout**: Masonry grid layout with automatic height based on content
- **Usage**: Displaying server information and services
- **CSS Classes**: `.server-card`

### Service Item
Service items are displayed within server cards and represent individual services.

- **Background (Static)**: `var(--service-background)`
- **Background (Hover)**: `var(--hover-service-item)`
- **Text Color**: `var(--service-text)` for name, `var(--secondary-text)` for port
- **Border Radius**: 4px
- **Padding**: 0.75rem
- **Height**: 40px (fixed height)
- **Margin**: 0.5rem gap between items
- **Usage**: Displaying service name, port, and status
- **CSS Classes**: `.service-item`

### No Services Message
A specific UI element displayed when a server has no services.

- **Background**: rgba(51, 51, 51, 0.3)
- **Text Color**: `var(--secondary-text)`
- **Font Style**: Italic
- **Text Alignment**: Center
- **Border Radius**: 4px
- **Padding**: 1rem 0
- **Margin**: 0.5rem 0 1.25rem
- **Usage**: Displayed when a server has no services
- **CSS Classes**: `.no-services`

## Notifications

Notifications are used to provide feedback to the user about actions or system events.

### Standard Notification
- **Position**: Fixed, bottom-right corner
- **Background**: `var(--accent-button)`
- **Text Color**: `var(--primary-button-text)` (typically white)
- **Border**: 1px solid `var(--accent-button)`
- **Border Radius**: 6px
- **Padding**: 12px 16px
- **Shadow**: 0 4px 12px rgba(0, 0, 0, 0.3)
- **Animation**: Slide in from right
- **Z-index**: 1000
- **Max Width**: 350px
- **Usage**: General informational messages
- **CSS Classes**: `.notification`

### Success Notification
- **Background**: `var(--status-green)`
- **Border**: 1px solid `var(--status-green)`
- **Usage**: Successful operations (e.g., "Settings saved successfully")
- **CSS Classes**: `.notification.success`

### Error Notification
- **Background**: `var(--status-red)`
- **Border**: 1px solid `var(--status-red)`
- **Usage**: Error messages or failed operations
- **CSS Classes**: `.notification.error`

### Animation
Notifications use a slide-in animation from the right side:

```css
@keyframes slide-in {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}
```

## Form Elements

### Input Field
- **Background**: `var(--service-background)`
- **Text Color**: `var(--server-text)`
- **Border**: 1px solid `var(--input-border, #444)`
- **Border (Focus)**: `var(--accent-button)` or `var(--service-text)`
- **Border Radius**: 4px
- **Padding**: 0.5rem
- **Width**: 100%
- **Font Size**: 1rem
- **Usage**: Text input in forms
- **CSS Classes**: `input`, `textarea`

### Checkbox
- **Accent Color**: `var(--accent-button)`
- **Label Font Size**: 0.9rem
- **Usage**: Boolean options in forms
- **CSS Classes**: `.checkbox-label input[type="checkbox"]`

## Color Variables

The UI components rely on the following CSS variables defined in the theme system:

- `--primary-button`: Primary button background color
- `--primary-button-text`: Text color for primary buttons
- `--secondary-button`: Secondary button background color
- `--secondary-button-text`: Text color for secondary buttons
- `--server-background`: Background color for server cards and tertiary buttons
- `--service-background`: Background color for service items
- `--hover-service-item`: Hover background color for service items
- `--service-text`: Text color for service names and buttons
- `--secondary-text`: Secondary text color for metadata and ports
- `--accent-text`: Color for accents and tertiary button outline/text
- `--status-red`: Color for error states and destructive actions
- `--status-green`: Color for success status
- `--status-amber`: Color for warning status 