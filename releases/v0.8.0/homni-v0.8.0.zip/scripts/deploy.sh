#!/bin/bash

# Color output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
ORANGE='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}=====================================================${NC}"
echo -e "${ORANGE}  Homni Dashboard Deployment Script${NC}"
echo -e "${BLUE}=====================================================${NC}"

# Change to the root directory first, then to source
cd "$(dirname "$0")/.." || {
  echo "Error: Could not find the root directory."
  exit 1
}

# Change to the source directory
cd "source" || {
  echo "Error: Could not find the source directory."
  exit 1
}

# Check if node is installed
if ! command -v node &> /dev/null; then
  echo "Error: Node.js is not installed. Please install Node.js to build this application."
  exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
  echo "Error: npm is not installed. Please install npm to build this application."
  exit 1
fi

# Install dependencies if needed
echo -e "${GREEN}Installing dependencies...${NC}"
npm install

# Build the application
echo -e "${GREEN}Building the application...${NC}"
npm run build

if [ $? -ne 0 ]; then
  echo -e "\nError: Build failed. Please check the errors above."
  exit 1
fi

# Copy the build files to the root directory
echo -e "${GREEN}Copying build files to production directory...${NC}"
cp -R dist/* ../ 

# Create images directory if it doesn't exist
echo -e "${GREEN}Setting up images directory...${NC}"
cd ..
mkdir -p images

# Copy only the necessary image files to the images directory
echo -e "${GREEN}Copying image assets...${NC}"
cp -f source/public/images/icon_white.png images/
cp -f source/public/images/icon_black.png images/
cp -f source/public/images/palette.png images/
cp -f source/public/images/config.png images/
cp -f source/public/images/vite.svg images/

# Remove orange icon if it exists
if [ -f "images/icon_orange.png" ]; then
  echo -e "${GREEN}Removing unused orange icon...${NC}"
  rm -f images/icon_orange.png
fi

# Remove image files from root directory
echo -e "${GREEN}Cleaning up image files from root directory...${NC}"
rm -f icon_*.png
rm -f palette.png
rm -f vite.svg

# Fix image paths in the production files
echo -e "${GREEN}Fixing image paths in production files...${NC}"
# Fix paths in CSS files
for cssfile in assets/index-*.css; do
  echo "  Processing: $cssfile"
  # Use sed to replace image paths
  sed -i '' 's|url(/icon_|url(/images/icon_|g' "$cssfile"
  sed -i '' 's|url(/palette.png)|url(/images/palette.png)|g' "$cssfile"
done

# Fix production index.html
echo "  Fixing paths in index.html..."
sed -i '' 's|href="/icon_|href="/images/icon_|g' index.html
sed -i '' 's|url('\''/icon_|url('\''/images/icon_|g' index.html

# Clean up asset files
echo -e "${GREEN}Cleaning up asset files...${NC}"
./scripts/clean-assets.sh

# Restart the server
echo -e "${GREEN}Restarting the server...${NC}"
pkill -f 'node server.js' || true
node server.js &

echo -e "\n${GREEN}Deployment complete!${NC}"
echo -e "Your application is now available at:"
echo -e "${GREEN}http://localhost:8080${NC}"

# Get IP address for easier access
ip=$(ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1' | head -n 1)

if [ ! -z "$ip" ]; then
  echo -e "Or from other devices on your network:"
  echo -e "${GREEN}http://$ip:8080${NC}"
fi

echo -e "${BLUE}=====================================================${NC}"
echo -e "To stop the server, run: ${ORANGE}pkill -f 'node server.js'${NC}"
echo -e "${BLUE}=====================================================${NC}"