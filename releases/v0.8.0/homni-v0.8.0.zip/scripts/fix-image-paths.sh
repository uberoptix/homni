#!/bin/bash

# Fix image paths in production CSS files
echo "Fixing image paths in CSS files..."

# Fix paths in production CSS files
for file in /Users/jforwood/Desktop/Homni/assets/index-*.css; do
  echo "Processing: $file"
  # Use sed to replace image paths
  sed -i '' 's|url(/icon_|url(/images/icon_|g' "$file"
  sed -i '' 's|url(/palette.png)|url(/images/palette.png)|g' "$file"
  echo "Updated: $file"
done

# Fix production index.html
echo "Fixing image paths in index.html..."
sed -i '' 's|href="/icon_|href="/images/icon_|g' /Users/jforwood/Desktop/Homni/index.html
sed -i '' 's|url('\''/icon_|url('\''/images/icon_|g' /Users/jforwood/Desktop/Homni/index.html

echo "Done! Image paths have been updated." 