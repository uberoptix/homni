# Homni v1.0.0 Release Notes

## 🚀 Deployment Update - May 8, 2023

- Server configuration updated to handle routes correctly
- Build and deployment script fixed and improved
- Production environment now mirrors development features exactly
- All assets properly organized and referenced
- Server hosting files directly from the root directory for better performance

## 🎉 Initial Release

This is the first stable release of Homni, a dashboard for managing self-hosted services.

### Features

- **Core Dashboard Functionality**
  - Add and manage servers by name and hostname
  - Add services with name, port, and optional path
  - Direct links to services

- **User Interface**
  - Plex-inspired dark theme with orange accents
  - Responsive layout for all screen sizes
  - Clean, modern design with cards for each server
  - Custom icons in orange, black, and white variants

- **Data Management**
  - Robust storage using IndexedDB with localStorage and sessionStorage fallbacks
  - Import/export functionality for data backup and transfer
  - Automatic saving of changes

- **User Experience**
  - Search bar to filter servers and services
  - Sort services by name or port
  - Masonry layout for efficient use of screen space
  - Footer with project information

- **Accessibility & Usability**
  - Keyboard shortcuts for common actions
  - Form navigation with Enter key
  - Visual indicators for active elements
  - Escape key functionality
  - Proper focus management

### Known Limitations

- Offline use only (no remote synchronization)
- No user accounts or multi-user support
- No automatic discovery of services

### Technical Details

- Built with React and TypeScript
- CSS styling without external frameworks
- Uses the Vite build system 