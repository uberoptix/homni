# Homni v1.0.0 Product Requirements Document (PRD)

## 1. Product Overview

Homni is a web-based dashboard application designed to help users manage and access their self-hosted services across multiple servers. The application provides a clean, intuitive interface with a dark theme inspired by Plex, offering users a centralized location to organize and access all their services.

## 2. Target Users

- Self-hosting enthusiasts
- System administrators
- Home lab users
- Anyone managing multiple servers or services

## 3. Core Features

### 3.1 Server Management
3.1.1 Add Servers. Users can add servers with a name and hostname.
3.1.2 Delete Servers. Users can remove servers from the dashboard.
3.1.3 Server Organization. Servers are displayed in a responsive grid layout.
3.1.4 Edit Servers. A config icon (config.png) appears next to the server IP address, allowing users to modify server details after creation. The icon is subtle but recognizable, maintaining the clean UI aesthetic.
3.1.5 Server Notes. Each server has a notes section (multi-line text field) where users can add custom information such as location, maintenance windows, or other important details. This information is accessible during both creation and modification of a server.

### 3.2 Service Management
3.2.1 Add Services. Users can add services to each server with name, port, and optional path.
3.2.2 Delete Services. Users can remove services from a server.
3.2.3 Service Navigation. Direct links to access services via HTTP/HTTPS.
3.2.4 Service Sorting. Users can sort services by name or port.

### 3.3 Search Functionality
3.3.1 Global Search. Users can search across all servers and services.
3.3.2 Real-time Filtering. Results update as the user types.
3.3.3 Clear Search. One-click option to clear search results.
3.3.4 Search Status. Visual feedback shows search results status.

### 3.4 Data Management
3.4.1 Persistent Storage. Data is stored locally using IndexedDB.
3.4.2 Fallback Storage. Supports localStorage and sessionStorage as fallbacks.
3.4.3 Import/Export. Users can backup and restore their dashboard data via JSON files.
3.4.4 Storage Status. Notifications inform users about the current storage method.
3.4.5 Notes Storage. Server notes are stored as part of the server object in the database and included in exports.

### 3.5 Customization
3.5.1 Color Palette. Users can customize the application's color scheme.
3.5.2 Theme Controls. Detailed color controls for all UI elements.
3.5.3 Color Preview. Live preview of color changes before saving.
3.5.4 Reset to Defaults. Option to revert to the default color palette.
3.5.5 Default Color Palette. The application uses the following default colors:
   - Header Background: #171717
   - Page Background: #1B1B1B
   - Server Background: #252525
   - Service Background: #333333
   - Primary Text: #e0e0e0
   - Accent Text: #DBA33A
   - Accent Text Hover: #ECBA58 (Lighter version of Accent Text)
   - Secondary Text: #a0a0a0
   - Button Color: #CC7B18
   - Status Colors:
     - Red: #ED6B5E
     - Amber: #F5BF4F
     - Green: #61C554

### 3.6 Keyboard Shortcuts
3.6.1 Add Server. Alt + A.
3.6.2 Import Data. Alt + I.
3.6.3 Export Data. Alt + E.
3.6.4 Customize Color Palette. Alt + P.
3.6.5 Focus Search. / or Alt + S.
3.6.6 Clear Search / Close Dialog. Esc.
3.6.7 Submit Form or Navigate Forms. Enter.
3.6.8 Navigate Between Fields. Tab.

### 3.7 UI/UX Features
3.7.1 Responsive Design. Works on devices of all sizes (desktop, tablet, mobile).
3.7.2 Intuitive Layout. Clean, organized interface with visual hierarchy.
3.7.3 Notifications. Transient notifications for user actions.
3.7.4 Welcome Screen. Information and guidance for new users.
3.7.5 Keyboard Navigation. Full keyboard accessibility.

## 4. Technical Implementation

### 4.1 Frontend Architecture
4.1.1 Framework. React with TypeScript.
4.1.2 Styling. Custom CSS with CSS variables for theming.
4.1.3 State Management. React Hooks (useState, useEffect).
4.1.4 Build System. Vite.

### 4.2 Data Storage
4.2.1 IndexedDB. Primary storage for servers, services, and settings.
4.2.2 localStorage. Fallback storage if IndexedDB is unavailable.
4.2.3 sessionStorage. Secondary fallback storage.

### 4.3 Deployment
4.3.1 Static Hosting. HTML/CSS/JS files can be served from any web server.
4.3.2 Local Server. Includes a simple Node.js server for local hosting.
4.3.3 Offline Support. Application functions without an internet connection.

## 5. User Workflows

### 5.1 Adding a Server
1. User clicks "Add Server" button or uses Alt+A shortcut
2. Dialog appears with fields for server name and hostname
3. User enters information and submits
4. Server card is added to the dashboard

### 5.2 Adding a Service
1. User clicks "Add Service" button on a server card
2. Dialog appears with fields for service name, port, and optional path
3. User enters information and submits
4. Service item is added to the server card

### 5.3 Accessing a Service
1. User clicks on a service item
2. Browser opens the service URL in a new tab
3. URL is constructed from server hostname, service port, and optional path

### 5.4 Searching for Services
1. User clicks on search field or uses / or Alt+S shortcut
2. User types search query
3. Dashboard filters to show only matching servers and services
4. User clicks on result or clears search

### 5.5 Customizing Colors
1. User accesses color palette dialog (Alt+P)
2. User adjusts colors using color pickers with live preview
3. User saves changes or cancels
4. If saved, new color scheme is applied immediately

### 5.6 Data Backup and Restore
1. User exports data via Export button or Alt+E
2. JSON file is downloaded with all dashboard data
3. User can later import this file via Import button or Alt+I
4. Dashboard is restored from the backup file

### 5.7 Editing Server Information
1. User clicks the config icon (config.png) next to the server IP address
2. A dialog appears with the server's current details pre-populated
3. User can modify server name, hostname, and notes
4. User saves changes or cancels
5. If saved, server information is updated immediately

## 6. Non-Functional Requirements

### 6.1 Performance
6.1.1 Loading Speed. Application should load quickly (<2 seconds).
6.1.2 UI Responsiveness. UI interactions should be responsive (< 100ms).
6.1.3 Scaling. Should handle at least 50 servers with 20 services each.

### 6.2 Compatibility
6.2.1 Browser Support. Works in all modern browsers (Chrome, Firefox, Safari, Edge).
6.2.2 Device Support. Responsive design works on desktop, tablet, and mobile devices.
6.2.3 Theme Support. Supports both light and dark mode system preferences.

### 6.3 Accessibility
6.3.1 Keyboard Navigation. Keyboard navigation throughout the application.
6.3.2 HTML Structure. Semantic HTML structure.
6.3.3 Color Contrast. Meets WCAG standards.
6.3.4 Screen Reader Support. Screen reader friendly.

### 6.4 Security
6.4.1 Local Storage. All data stored locally (no server communication).
6.4.2 Data Privacy. No sensitive information transmitted.

### 6.5 Offline Functionality
6.5.1 Offline Operation. Application functions without internet connectivity.
6.5.2 Data Persistence. Data persistence across browser sessions.

## 7. Future Enhancements

### 7.1 Potential Features for Future Versions
7.1.1 Status Monitoring. Monitor service uptime and availability.
7.1.2 Multi-user Support. Shared dashboards across users.
7.1.3 Service Categories. Tagging and categorization of services.
7.1.4 Service Documentation. Ability to add notes and documentation.
7.1.5 Dashboard Widgets. Statistics and monitoring widgets.
7.1.6 Backup Automation. Scheduled backups and data exports.
7.1.7 Theme Toggle. Switching between dark and light themes.
7.1.8 Dependency Mapping. Visual mapping of service dependencies.
7.1.9 Custom Icons. Ability to set custom icons for services.
7.1.10 Monitoring Integration. Integration with third-party monitoring tools.

## 8. Development and Deployment Requirements

### 8.1 Development Environment
8.1.1 Runtime. Node.js.
8.1.2 Package Management. npm or yarn.
8.1.3 Browser. Modern web browser.
8.1.4 Editor. Code editor.

### 8.2 Deployment Requirements
8.2.1 Server. Basic web server or Node.js for the included server.js.
8.2.2 Database. No database requirements (client-side storage only). 