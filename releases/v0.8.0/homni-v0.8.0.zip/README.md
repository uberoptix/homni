# Homni v0.8.0

A beautiful dashboard for managing and accessing your self-hosted services across multiple servers.

## Features

- Add and organize servers and services
- Quick access to your services with direct links
- Search functionality to filter servers and services
- Import/export capabilities for data backup
- Dark theme with orange accents inspired by Plex
- Keyboard shortcuts for improved usability
- Responsive design that works on all devices
- Offline-first with robust storage using IndexedDB
- Customizable color palette for personalization

## Installation

```bash
# Make the installation script executable
chmod +x scripts/install.sh

# Run the installation script
./scripts/install.sh
```

## Usage

To start the server:
```bash
./scripts/start.command
```

To stop the server:
```bash
./scripts/stop.command
```

The application will be available at http://localhost:8080.

## Keyboard Shortcuts

- `Alt + A` - Add Server
- `Alt + I` - Import Data
- `Alt + E` - Export Data
- `Alt + P` - Customize Color Palette
- `/` or `Alt + S` - Focus Search
- `Esc` - Clear Search / Close Dialog
- `Enter` - Submit Form or Navigate Forms
- `Tab` - Navigate Between Fields

## Development

### Directory Structure

- `/source` - Contains the source code for the application
  - `/src` - React source files
    - `/assets` - Source-level assets used in the React application
  - `/public` - Static assets for development
    - `/images` - Image assets (icons, logos, etc.)
  - `/tools` - Development tools and utilities
- `/assets` - Generated CSS and JS assets for production
- `/images` - Image assets for production (copied from source/public/images)
  - `/source_files` - Raw image files and design templates (Photoshop, Affinity, etc.)
- `/scripts` - Utility scripts for deployment and maintenance
- `/docs` - Documentation files
- `/releases` - Contains release packages and archives
- `/temp` - Temporary files used during build and development

### Development Workflow

1. Make changes to files in the `/source` directory
2. Run development server with `cd source && npm run dev`
3. Build for production with `cd source && npm run build`
4. Deploy to production with `./scripts/deploy.sh` (copies builds files and sets up assets)
5. The production server will be restarted automatically

### Scripts Reference

The `scripts` directory contains various utility scripts for managing the application:

- `install.sh` - Initial installation script that sets up dependencies, makes scripts executable, and runs the deployment script
- `start.command` - Starts the Homni server on http://localhost:8080
- `stop.command` - Stops any running Homni server processes
- `deploy.sh` - Builds the application, copies files to production directories, and restarts the server
- `clean-css.sh` - Removes older CSS files, keeping only the most recent one to maintain a clean assets directory
- `fix-image-paths.sh` - Updates image paths in CSS and HTML files to point to the correct locations
- `create-release.sh` - Creates a zip archive of the application for distribution, placing it in the releases directory

### Production Server

A simple Node.js server is included to serve the application. Start it with:

```bash
./scripts/start.command
```

## Data Storage

Homni uses IndexedDB as the primary storage method, with localStorage and sessionStorage as fallbacks.
Your data is stored locally in your browser and is never sent to any external servers.

## Version History

### v0.8.0 (Current)
- Improved asset management system with centralized image organization
- Added images/source_files directory for raw image files and design templates
- Enhanced deployment script to prevent image duplication in root directory
- Added automatic cleanup of older JavaScript files during deployment
- Renamed clean-css.sh to clean-assets.sh with expanded functionality
- Improved organization of project directory structure
- Updated README with comprehensive documentation on project structure and scripts

### v0.5.0
- Added new keyboard shortcuts for improved usability
- Implemented custom color palette functionality
- Enhanced import/export capabilities for data backup
- Improved responsive design for mobile and tablet devices
- Added support for offline-first operation with robust IndexedDB storage

### v0.3.0
- Migrated from Vite dev server to custom Node.js production server
- Restructured project with separate development and production environments
- Implemented deployment workflow with automated build process
- Added scripts directory with utility scripts for deployment and maintenance
- Improved CSS structure with custom styling

### v0.1.0 (Initial Release)
- Basic dashboard functionality for managing self-hosted services
- Add and organize servers and services
- Quick access to services with direct links
- Search functionality to filter servers and services
- Dark theme with orange accents inspired by Plex

## Created By

Homni is a passion project by James Forwood.
© 2025 All Rights Reserved. 