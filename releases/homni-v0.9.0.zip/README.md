# Homni Dashboard

A self-hosted monitoring dashboard for servers and services.

## Features

- Server and service monitoring
- Status indicators (Red/Amber/Green)
- Light and dark theme support with Evernote-inspired light theme and amber-accented dark theme
- Customizable color palette
- Responsive design
- Smart search prioritizing services over servers
- True CSS-based masonry grid layout for optimal content distribution
- Intelligent server card ordering based on content size

## Development Workflow

We use a production-focused workflow for all development. We've deliberately simplified to a single production-only workflow with no separate development server.

```bash
# From the Homni root directory
./deploy.sh
```

This script will:
- Kill any running server instances
- Ensure dependencies are up-to-date
- Build the source files
- Create a backup of the current production files
- Copy the build files to the production directory
- Start the server at http://localhost:8080/

### Why We Use This Approach

The dual development/production environment was causing synchronization issues, particularly with:
- Search logic implementation
- Style consistency 
- HMR updates not being properly applied
- Caching issues resulting in inconsistent UI updates

By focusing on a single production-ready workflow, we ensure:
- What you see is exactly what gets deployed
- No confusion about which environment is "correct"
- Streamlined testing and verification process
- Elimination of caching and hot-reload inconsistencies

### When Making Changes

1. Edit files in the `/source` directory 
2. Run `./deploy.sh` to see your changes at http://localhost:8080
3. Test thoroughly in the production environment
4. When finished, press Ctrl+C to stop the server 

**Important:** Do NOT run `npm run dev` to start a development server. Always use `./deploy.sh` for all development activities.

## Production Deployment

For production deployment:

```bash
# From the Homni root directory
./deploy.sh
```

The script automatically creates backups of previous deployments in the `releases` directory.

## Building and Running Manually

If you need to perform steps individually:

```bash
# Install dependencies
cd source
npm ci || npm install

# Build for production
npm run build

# Copy files to production directory
cd ..
cp -r source/dist/* .

# Start the server
node scripts/server.js
```

## Project Structure

- `/source` - Source code directory
  - `/source/src` - React application code
  - `/source/public` - Static assets for development
    - `/source/public/images` - Images used by the application 
- `/assets` - Production assets
- `/images` - Production images directory
- `/releases` - Deployment backups
- `/docs` - Documentation and version information
- `/scripts` - Server and utility scripts
- `/custom.css` - Global CSS overrides for production

## Utility Scripts

The project includes several utility scripts in the `/scripts` directory to help with common tasks:

### Core Scripts

- `deploy.sh` - Main deployment script that builds the application, creates backups, and starts the server
- `server.js` - Simple HTTP server for serving the application
- `start.command` - macOS-friendly script to start the server (can be double-clicked)
- `stop.command` - macOS-friendly script to stop the server (can be double-clicked)

### Installation and Updates

- `install.sh` - Sets up the project by installing dependencies and initializing directories
- `update-version.sh` - Updates version information across the project and creates release note templates
- `create-release.sh` - Creates a zip file of the release for distribution

### Maintenance and Fixes

- `clean-assets.sh` - Cleans up old CSS and JS files in the assets directory
- `fix-notes-visibility.sh` - Diagnostic script for fixing issues with service notes visibility
- `fix-image-paths.sh` - Corrects image paths in CSS and HTML files to ensure proper referencing

## Documentation

- The Product Requirements Document (PRD) in docs/PRD.md contains comprehensive documentation about all features, including the search system and theme specifications.
- [Masonry Implementation](docs/MASONRY_IMPLEMENTATION.md) - Details on the masonry layout implementation
- [UI Design Guide](docs/UI_DESIGN_GUIDE.md) - Comprehensive guide for UI styling conventions including buttons, cards, and notifications
- [Release Notes](docs/RELEASE_NOTES.md) - Details of changes in each release
- [Backup and Release Protocol](docs/BACKUP_AND_RELEASE_PROTOCOL.md) - Documentation of backup and release management standards

## License

Copyright © 2024 